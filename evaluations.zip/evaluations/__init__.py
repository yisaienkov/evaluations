"""Evaluations library"""

__version__ = "0.0.4"

__all__ = [
    'classification',
    'text_extraction',
    'kaggle_2020',
]
